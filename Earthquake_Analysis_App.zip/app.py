# Streamlit app entry point
import streamlit as st
st.title('Earthquake Dashboard')