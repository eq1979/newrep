How to Run:

1. Unzip the file
2. Run 'pip install -r requirements.txt'
3. Run 'streamlit run app.py'