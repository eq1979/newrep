# Fetch earthquake data from USGS
def fetch_data():
    pass